require('./config/config');

const express = require('express');
const hbs = require('hbs');
const fs = require('fs');
const bodyParser = require('body-parser');
const _ =require('lodash');
const cors = require('cors');
const {mongoose} = require('./db/mongoose.js');

const port = process.env.PORT || 3000;
const {PaymentInfo} = require('./models/PaymentInfo.js');
const app = express();

app.use(cors());

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

hbs.registerPartials(__dirname+'/views/partials');
app.set('view engine','hbs');

hbs.registerHelper('getCurrentYear', () => {
    return new Date().getFullYear();
});

app.use((req, res, next) => {
    var now = new Date().toString();
    var log = `${now}: ${req.method} ${req.url}`;

    console.log(log);
    fs.appendFile('server.log', log + '\n', (err) => {
        if (err) throw err;
        console.log(`The data ${log} was appended to the server log file.`); 
    });
    next();
});

// app.use((req, res, next) => {
//     res.render('maintenance.hbs', {
//         title: 'Maintenance',
//         description: 'The site is under maintenance'
//     });
// });

app.use(express.static(__dirname +'/public'));

app.get('/', (req, res, next) => {
   res.render('home.hbs',{
       title: 'Home Page',
       description: 'Home Page description'
   });
});

app.get('/about', (req, res, next) => {
    res.render('about.hbs',{
       title: 'About Page',
       description: 'About Page description'
    });
});

app.get('/paymentlist', (req, res, next) => {
    
    PaymentInfo.find().then((paymentList) => {
        console.log(JSON.stringify(paymentList,undefined, 2));
        res.render('paymentlist.hbs',{
            title: 'Payment List',
            description: 'Payment List',
            paymentList: paymentList
         });
    }).catch((error) => {
        res.render('paymentlist.hbs',{
            title: 'Payment List',
            description: 'Payment List retrieval failed.'
         });
    });
});

app.get('/paymentinfo', (req, res, next) => { 
        res.render('paymentinfo.hbs',{
            title: 'Payment info',
            description: 'Payment info update'
         });
});

app.post('/paymentinfo', (req, res, next) => {
    var body = _.pick(req.body, ['cardname','cardnumber','expmonth','expyear']);
    console.log(JSON.stringify(body, undefined, 2));
    var paymentInfo = new PaymentInfo(body);
    paymentInfo.save().then((doc) => {
        res.render('paymentinfoupdate.hbs',{
            title: 'Payment Info Update Details',
            description: 'Payment Info Form submitted successfully'
         });
    }).catch((error) => {
        res.render('paymentinfoupdate.hbs',{
            title: 'Payment Info Update Details',
            description: 'Payment Info Form submission failed'
         });
    });
});

//Web server port
app.listen(port, () => {
    console.log(`Server started on the port: ${port}`);
});