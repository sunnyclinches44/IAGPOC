const mongoose = require('mongoose');

var PaymentInfo = mongoose.model('PaymentInfo', {
    cardname:{
        type: String,
        required: true,
        minlength: 1,
        trim: true
    },
    cardnumber: {
        type: Number,
        default: null
    },
    expmonth:{
        type: String,
        default: null
    },
    expyear:{
        type: String,
        default: null
    }
});


module.exports = {
    PaymentInfo
};